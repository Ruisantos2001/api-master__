package paises.api.service;
import paises.api.domain.Pais;

public record DadosListagemPais(long id, String name, String capital, String area, String region)
{
    public DadosListagemPais(Pais pais )
    {
        this(pais.getId(),pais.getName(),pais.getCapital(),pais.getArea(),pais.getRegion());
    }
}
