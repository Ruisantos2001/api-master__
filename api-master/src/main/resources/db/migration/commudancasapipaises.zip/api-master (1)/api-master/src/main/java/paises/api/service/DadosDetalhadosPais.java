package paises.api.service;

import paises.api.domain.Pais;

public record DadosDetalhadosPais(Long id, String name, String capital, String region, String subregion, String area)
{
    public DadosDetalhadosPais(Pais pais)
    {
        this(pais.getId(),pais.getName(),pais.getCapital(),pais.getRegion(),pais.getSubregion(),pais.getArea());
    }
}