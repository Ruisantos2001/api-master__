package paises.api.service;

import jakarta.validation.constraints.NotBlank;
import paises.api.domain.Pais;

public record DadoscriarPais(@NotBlank String name, @NotBlank String capital, @NotBlank String region, @NotBlank String subregion, @NotBlank String area)//uma classe imutavel , usada para enviar ou receber dados
{

}
