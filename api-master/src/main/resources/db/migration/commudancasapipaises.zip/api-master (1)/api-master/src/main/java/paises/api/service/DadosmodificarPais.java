package paises.api.service;
import jakarta.validation.constraints.NotNull;

public record DadosmodificarPais(String capital, String area)
{

}
