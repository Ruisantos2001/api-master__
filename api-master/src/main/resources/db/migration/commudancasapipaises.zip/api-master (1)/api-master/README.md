Uma API RESTful que nos permite gerenciar as informações das propriedades dos países (identificador – gerado automaticamente, nome, capital, região, sub-região, área).
Funções:
1-Deve ser possível criar um novo país a partir da API criada com todas as suas propriedades;
2-Deve ser possível listar todos os países anteriormente criados;
3-Deve ser possível modificar os dados de um país anteriormente criado;
4-Deve ser possível eliminar um país anteriormente criado;
5-Deve ser possível ordenar a lista dos países por qualquer uma das suas propriedades.
