package paises.api.presentation;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import paises.api.domain.Pais;
import paises.api.persistence.PaisRepository;
import paises.api.service.DadosDetalhadosPais;
import paises.api.service.DadosListagemPais;
import paises.api.service.DadoscriarPais;
import paises.api.service.DadosmodificarPais;

@RestController //para identificar  que esta classe e um controller
@RequestMapping("/paises") //sempre que chegar uma requesição do tipo paises ele vai chamar esse PaisController
public class PaisController
{
    @Autowired //para instanciar o repositorio sozinho
    private PaisRepository repository;

    @PostMapping()
    public ResponseEntity <Pais> criar(@RequestBody@Valid DadoscriarPais dados)//, UriComponentsBuilder uriBuilder) //método para criar um pais
    {
        Pais pais=new Pais(dados);
        return ResponseEntity.status(HttpStatus.CREATED).body(repository.save(pais));
    }

    @GetMapping()
    public ResponseEntity<Page<DadosListagemPais>> listar(@PageableDefault(size=10,sort={"nome"}) Pageable paginacao) //método para mostrar paises, e ordenar os países por qualquer uma das suas propriedades.
    {
        Page <DadosListagemPais>page =repository.findAll(paginacao).map(DadosListagemPais::new);
        return ResponseEntity.ok(page);
    }


    @PutMapping("/{id}")
    public ResponseEntity<DadosDetalhadosPais> modificar(@RequestBody@Valid DadosmodificarPais dados, @PathVariable Long id)//método para modificar os dados de um país anteriormente criado
    {
        Pais pais=repository.getReferenceById(id);
        pais.modificardados(dados);
        Pais saved=repository.save(pais);
        return ResponseEntity.ok(new DadosDetalhadosPais(saved));

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id ) //método pathvariable indica que a variavel id e uma variavel do caminho.
    {
       repository.deleteById(id);
       return ResponseEntity.noContent().build();//para notificar que esta requisição não retorna um conteudo
    }

    @GetMapping("/{id}")
    public ResponseEntity visualizar(@PathVariable Long id) //método para visualizar determinado pais
    {
        Pais pais = repository.getReferenceById(id);
        return ResponseEntity.ok(new DadosDetalhadosPais(pais));
    }
}